# Text collector example scripts

The scripts have been moved to
https://github.com/prometheus-community/node-exporter-textfile-collector-scripts
